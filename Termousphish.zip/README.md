# Phishing Instagram v.007
# Coded by:Turub_Termous
# Partner :Online_Fighter.50
# Instagram:https://instagram.com/turub_termous?utm_medium=copy_link
# Telegram :https://t.me/Turub_Termous



 				       TERITORIAL				
		   Pertama ini nya di giniin,kemudian itu nya di gituin.
