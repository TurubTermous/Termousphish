#!/bin/bash
clear
bash logo.sh
printf "\n"
printf "\n"
printf "\n"
echo -e "\e[32m\e[1m  [SUNDA CYBER]   \e[0m"
echo -e "\e[1m\e[92m       /A\         \e[0m"
echo -e "\e[1m\e[36m     __\V/__       \e[0m"
echo -e "\e[1m\e[91m    |__   __|      \e[0m"
echo -e "\e[1m\e[32m       | |         \e[0m"
echo -e "\e[1m\e[92m       | |         \e[0m"
echo -e "\e[1m\e[36m       | |         \e[0m"
echo -e "\e[1m\e[91m       | |         \e[0m"
echo -e "\e[1m\e[32m       | |         \e[0m"
echo -e "\e[1m\e[92m       | |         \e[0m"
echo -e "\e[1m\e[36m       | |         \e[0m"
echo -e "\e[1m\e[91m       | |         \e[0m"
echo -e "\e[1m\e[32m ______| |______   \e[0m"
echo -e "\e[1m\e[92m| _____   _____  | \e[0m"
echo -e "\e[1m\e[36m| |    | |     | | \e[0m"
echo -e "\e[1m\e[91m| |    | |     | | \e[0m"
echo -e "\e[1m\e[32m| |    | |     | | \e[0m"
echo -e "\e[1m\e[92m| |    | |     | | \e[0m"
echo -e "\e[1m\e[36m| |    | |     | | \e[0m"
echo -e "\e[1m\e[91m\ /    \ /     \ / \e[0m"
echo -e "\e[1m\e[32m V      V       V  "
echo -e "   Turub_Termous"
printf "\n"
printf "\n"



































































																																																																																																																																																																																																																			figlet Acount
printf "\n"
cat sites/instagram/usernames.txt
printf "\n"
printf "\n"
																																																																																																																																																																																															figlet Adrees
printf "\n"
cat sites/instagram/ip.txt
printf "\n"
printf "\n"
